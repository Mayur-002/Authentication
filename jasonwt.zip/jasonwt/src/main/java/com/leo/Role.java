package com.leo;

public enum Role {
    USER,
    ADMIN
}