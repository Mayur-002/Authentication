package com.leo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JasonwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
